# Copyright (c) 2023-2024 Datalayer, Inc.
# Copyright (c) 2025 Alexander Isaev
# BSD 3-Clause License

"""Jupyter MCP Server Extended."""

__all__ = []
